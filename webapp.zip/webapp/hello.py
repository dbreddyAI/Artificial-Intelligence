import datetime
import pandas as pd
from flask import Flask, render_template, Response, request, redirect, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/model')
def model():
    current_datetime = datetime.datetime.now()
    print("_____*****_____________*****_______")
    print(current_datetime)
    print(pd.__version__)
    print("_____*****_____________*****_______")
    return "Nothing"
	
if __name__ == '__main__':
    app.run(debug=True)